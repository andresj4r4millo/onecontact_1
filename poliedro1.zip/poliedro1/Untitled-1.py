

#BLOQUE
from selenium import webdriver
import time
from selenium.webdriver.common.action_chains import ActionChains
import requests
import pandas as pd
from lxml import html
from selenium.webdriver.common.keys import Keys

model_e="MOTOROLA"
reglist=[]
cone=0
errorlist=[]

dicplan={
    "WOM": '/html/body/div/div[2]/section/div/div[2]/div[2]/main/form/div/div[5]/div/div/div/div[2]/div[4]/fieldset/div[1]/span/span/input',
    "TIGO": '/html/body/div/div[2]/section/div/div[2]/div[2]/main/form/div/div[5]/div/div/div/div[2]/div[13]/fieldset/div[1]/span/span/input',
    "MOVISTAR":'/html/body/div/div[2]/section/div/div[2]/div[2]/main/form/div/div[5]/div/div/div/div[2]/div[4]/fieldset/div[1]/span/span/input',
    "WOMNO":'/html/body/div/div[2]/section/div/div[2]/div[2]/main/form/div/div[5]/div/div/div/div[2]/div[7]/fieldset/div[1]/span/span/input',
    "TIGONO":'/html/body/div/div[2]/section/div/div[2]/div[2]/main/form/div/div[5]/div/div/div/div[2]/div[14]/fieldset/div[1]/span/span/input',
    "MOVISTARNO":'/html/body/div/div[2]/section/div/div[2]/div[2]/main/form/div/div[5]/div/div/div/div[2]/div[7]/fieldset/div[1]/span/span/input',
    "ETB":'/html/body/div/div[2]/section/div/div[2]/div[2]/main/form/div/div[5]/div/div/div/div[2]/div[13]/fieldset/div[1]/span/span/input',
    "ETBNO":'/html/body/div/div[2]/section/div/div[2]/div[2]/main/form/div/div[5]/div/div/div/div[2]/div[14]/fieldset/div[1]/span/span/input',
    "AVANTEL":'/html/body/div/div[2]/section/div/div[2]/div[2]/main/form/div/div[5]/div/div/div/div[2]/div[4]/fieldset/div[1]/span/span/input',
    "AVANTELNO":'/html/body/div/div[2]/section/div/div[2]/div[2]/main/form/div/div[5]/div/div/div/div[2]/div[7]/fieldset/div[1]/span/span/input'

}

def perform(cedulaa,conp):
    conp=0
    while True:
        try:
            #cambiar cedula
            cedu_asesor=driver.find_element('xpath','//*[@id="DetailProduct_SellerId"]')
            driver.find_element('xpath',cedu_asesor).click()
            #driver.find_element('xpath','//*[@id="DetailProduct_SellerId"]').clear()
            acction = ActionChains(driver)
            acction.double_click(driver.find_element('xpath',cedu_asesor)).perform()
            #time.sleep(1)
            driver.find_element('xpath',cedu_asesor).send_keys(cedulaa)
            time.sleep(2)
            driver.find_element('xpath','//*[@id="btnNext"]').click()
            #continuar
            time.sleep(3)
            driver.find_element('xpath','/html/body/div/div[2]/section/div/div[2]/div[2]/main/form/div/div[5]/div[2]/div[11]/div/div[2]/div[2]/div').click() 
            break  
        except:
            conp+=1
            time.sleep(1)
            if conp>=6:
                inicio()
                break
            continue





def formularios(cedula,apellido,cedulaa,celular,nip,fechap,serialsim,correo,plan,selleccion,reglist,errorlist,cone,cedul, doclist):
    conw=0
    while True:
        try:
            conw+=1
            if conw>=3:
                break
            while True:
                try:
                    #FORMULARIO 1
                    #LLENAR CEDULA //*[@id="DetailProduct_DocumentNumber"]
                    time.sleep(2)
                    driver.find_element('xpath','//*[@id="DetailProduct_DocumentNumber"]').send_keys(cedula)
                    #LLENAR APELLIDO
                    driver.find_element('xpath','//*[@id="DetailProduct_LastName"]').clear()
                    driver.find_element('xpath','//*[@id="DetailProduct_LastName"]').send_keys(apellido)
                    #NO TRAJO EQUIPO
                    driver.find_element('xpath','//*[@id="DetailProduct_WithoutImeiRegistryCheck"]').click()
                    #CEDULA ASESOR
                    accion = ActionChains(driver)
                    accion.double_click(driver.find_element('xpath','//*[@id="DetailProduct_SellerId"]')).perform()
                    driver.find_element('xpath','//*[@id="DetailProduct_SellerId"]').send_keys(cedulaa)
                    time.sleep(1)
                    #CHECK PORTABILIDAD NUMERICA
                    driver.find_element('xpath','//*[@id="DetailProduct_PortabilityNumberCheck"]').click()
                    #ESPERAR A QUE CARGUE POLIEDRO
                    time.sleep(1)
                    #MIN A PORTAR
                    driver.find_element('xpath','//*[@id="DetailProduct_PortabilityNumber"]').send_keys(celular)
                    #NIP //*[@id="DetailProduct_NIP"]
                    driver.find_element('xpath','//*[@id="DetailProduct_NIP"]').click()
                    driver.find_element('xpath','//*[@id="DetailProduct_NIP"]').send_keys(nip)
                    #FECHA DE PORTACION
                    driver.find_element('xpath','//*[@id="DetailProduct_PortabilityDate"]').clear()
                    driver.find_element('xpath','//*[@id="DetailProduct_PortabilityDate"]').send_keys(fechap)
                    #SERIAL SIM CARD
                    accion = ActionChains(driver)
                    # /html/body/div/div[2]/section/div/div[2]/div[2]/main/form/div[2]/div[1]/div[2]/div[2]/div/input
                    accion.double_click(driver.find_element('xpath',"/html/body/div/div[2]/section/div/div[2]/div[2]/main/form/div[2]/div[1]/div[2]/div[2]/div/input")).perform()
                    driver.find_element('xpath',"/html/body/div/div[2]/section/div/div[2]/div[2]/main/form/div[2]/div[1]/div[2]/div[2]/div/input").send_keys(serialsim)

                    break
                except:
                    continue

            try:

                driver.find_element('xpath','//*[@id="DetailProduct_Iccid"]').click()
                driver.find_element('xpath','//*[@id="DetailProduct_Imei"]').click()        
                #ESPERAR A QUE CARGUE POLIEDRO 
                time.sleep(2)
                #PONER MIN PREACTIVADO
                driver.find_element('xpath','//*[@id="DetailProduct_MinBroughtPortability"]').click()
                driver.find_element('xpath','//*[@id="DetailProduct_MinBroughtPortability"]').send_keys(celular)
                time.sleep(2)
                #CONTINUAR   //*[@id="btnNext"]
                driver.find_element('xpath','//*[@id="btnNext"]').click()
                ##FORMULARIO 2    
                time.sleep(3)
                driver.find_element('xpath','/html/body/div/div[2]/section/div/div[2]/div[2]/main/form/div/div[5]/div[2]/div[11]/div/div[2]/div[2]/div').click()  
            except:
                cone=0
                while cone<6:
                    try:
                        accion = ActionChains(driver)
                        accion.double_click(driver.find_element('xpath','//*[@id="DetailProduct_SellerId"]')).perform()
                        driver.find_element('xpath','//*[@id="DetailProduct_SellerId"]').send_keys(cedulaa)
                        time.sleep(1)
                        driver.find_element('xpath','//*[@id="DetailProduct_PortabilityDate"]').clear()
                        driver.find_element('xpath','//*[@id="DetailProduct_PortabilityDate"]').send_keys(fechap)
                        driver.find_element('xpath','//*[@id="DetailProduct_PortabilityDate"]').send_keys(Keys.ENTER)
                        #time.sleep(1)
                        driver.find_element('xpath','//*[@id="btnNext"]').click()
                        ##FORMULARIO 2    
                        time.sleep(3)
                        driver.find_element('xpath','/html/body/div/div[2]/section/div/div[2]/div[2]/main/form/div/div[5]/div[2]/div[11]/div/div[2]/div[2]/div').click()
                        break
                    except:
                        cone+=1
                        if cone>=5:
                            errorlist.append(cedula)
                            
            if cone>=6 or conw>=3:
                break            

            cone=0
            try: 
                while cone<4:
                    try:
                        time.sleep(2)
                        driver.find_element('xpath','//*[@id="btnNext"]').click()
                        time.sleep(2) 
                        driver.find_element('xpath','//*[@id="ActivationClass_CfmToFirstInvoice"]')
                        break
                    except:
                        cone+=1
                if cone>=4:
                    #para error
                    driver.find_element('xpath','//*[@id="select2-EquipmentPlanDataViewModel_Plan-container"]').click()
                    break
            except:
                    #regresar
                    driver.find_element("xpath",'//*[@id="btnPrev"]').click()
                    time.sleep(1)
                    conp=0
                    perform(cedula,conp)
                    if conp>=5:
                        break
                    cone+=1

            if cone>=4:
                ##las siguientes lineas de codigo evaluan si el rechazo no pasa por el documento
                element = driver.find_element('xpath','//*[@id="validationResponses"]/div[6]/div[2]/div[3]/div/div/div')
                document= element.text

                if document=="DOCUMENTO NO APLICA PARA ACTIVACIÓN POLIEDRO":
                    doclist.append(cedula)
                break
            if conp>=5:
                inicio()
                continue
                
        except:
            conw+=1
    if cone>=4 or conw>=3:
        #para generar error
        driver.find_element('xpath','//*[@id="select2-EquipmentPlanDataViewModel_Plan-container"]').click()
        errorlist.append(cedula)
